#!/usr/bin/env bash
set -euo pipefail

if [[ -f /opt/ros/humble/setup.bash ]]; then
    source /opt/ros/humble/setup.bash
fi

if [[ -n "${ROBOT_WORKSPACE_SETUP:-}" && -f "${ROBOT_WORKSPACE_SETUP}" ]]; then
    source "${ROBOT_WORKSPACE_SETUP}"
fi

exec "$@"
