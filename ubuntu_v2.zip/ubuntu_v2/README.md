# Robot Control v2

This is a new implementation. Existing `local_test/` and `robot_project/` files are
not modified.

## Deployment architecture

```text
Windows or macOS                          Ubuntu virtual machine              Physical robot
┌─────────────────────────┐              ┌──────────────────────────┐       ┌──────────────┐
│ PySide6 GUI             │  TCP 9999   │ Docker Compose           │ ROS2  │ motors       │
│ local camera → YOLO     ├─────────────►│ command bridge → cmd_vel ├──────►│ LiDAR       │
│ manual/follow controls  │◄─────────────┤ telemetry                │◄──────┤ servos      │
└─────────────────────────┘              │ micro-ROS agent          │       └──────────────┘
                                         │ Yahboom base node        │
                                         └──────────────────────────┘
```

The GUI connects to the **Ubuntu VM IP**, not directly to the physical robot. Camera
capture and YOLO run on Windows/macOS. Docker does not need a camera device.

## 1. Network requirements

Use a bridged network adapter for the Ubuntu VM whenever possible. The following
paths must work:

- Windows/macOS host → Ubuntu VM TCP port 9999;
- Ubuntu VM → physical robot network;
- physical robot micro-ROS client → Ubuntu VM UDP port 8888 by default.

NAT with a TCP 9999 port-forward may let the GUI connect, but ROS2 discovery and
micro-ROS UDP can still fail. If Wi-Fi bridging is unsupported by the hypervisor,
pass a separate USB Wi-Fi adapter through to the Ubuntu VM.

Check the VM address:

```bash
ip -br address
```

Set the physical robot's micro-ROS agent address to that VM IP. Give the VM a DHCP
reservation or static address so the GUI and robot configuration do not change.

If UFW is active, allow only the trusted robot/LAN subnet where practical. Basic
ports are:

```bash
sudo ufw allow 9999/tcp
sudo ufw allow 8888/udp
```

## 2. Configure the Ubuntu VM

Docker Engine and the Docker Compose plugin must be installed.

```bash
cd ubuntu_v2
cp .env.example .env
nano .env
```

Important settings:

```dotenv
ROBOT_WORKSPACE_SETUP=/root/ros2_ws/install/setup.bash
BASE_NODE_PACKAGE=yahboomcar_base_node
BASE_NODE_EXECUTABLE=base_node_X3
MICROROS_AGENT_ARGS=udp4 --port 8888 -v6
COMMAND_TOKEN=replace-with-a-private-value
```

For a serial robot connection passed directly into the VM, change the agent setting
and add the matching Docker device mapping before use:

```dotenv
MICROROS_AGENT_ARGS=serial --dev /dev/ttyUSB0 -b 115200 -v6
```

Do not start `base_node_X3` twice. If another Ubuntu service already owns
`/YB_Car_Node`, disable that service or omit the Compose `base-node` service.

## 3. First Docker run in the Ubuntu VM

```bash
cd ubuntu_v2
docker compose config
docker compose build
docker compose up -d
docker compose ps
```

Expected services:

```text
robot-v2-micro-ros-agent
robot-v2-base-node
robot-v2-cmd-bridge
```

Diagnostics:

```bash
docker compose logs -f micro-ros-agent
docker compose logs -f base-node
docker compose logs -f cmd-bridge
```

Container IDs may change after recreation; operations use stable Compose service and
container names, so nothing depends on an ID.

## 4. Start Docker automatically with the Ubuntu VM

After the direct test succeeds:

```bash
cd ubuntu_v2
sudo ./scripts/install_vm_ubuntu.sh
sudo nano /opt/robot-control-v2/.env

cd /opt/robot-control-v2
sudo docker compose config
sudo docker compose build
sudo systemctl start robot-control-v2
sudo systemctl status robot-control-v2
```

The service is enabled for future VM boots. Docker logs are limited to three 10 MB
files per service.

## 5. Install the GUI on Windows

Install 64-bit Python, preferably Python 3.11. Open PowerShell in
`ubuntu_v2\desktop_gui` and run once:

```powershell
powershell -ExecutionPolicy Bypass -File .\setup_gui_windows.ps1
```

After installation, double-click the hidden-console launcher:

```text
run_gui_windows.vbs
```

`run_gui_windows.bat` is also available when console output is needed for debugging.

Windows may ask for camera and network firewall permission on first run.

## 6. Install the GUI on macOS

Install Python 3, then run once in Terminal:

```bash
cd ubuntu_v2/desktop_gui
chmod +x setup_gui_macos.sh
./setup_gui_macos.sh
```

After installation, double-click `Robot Control v2.app`. Grant camera permission in
**System Settings → Privacy & Security → Camera** if macOS asks.

## 7. GUI settings and daily operation

Enter:

- **Ubuntu VM IP**: the bridged VM address;
- **Command port**: `9999`;
- **Control token**: the VM `.env` `COMMAND_TOKEN` value;
- **Camera input**: normally `This computer's camera`, index `0`;
- **YOLO model**: select `yolov8n-pose.pt`.

For an IP/MJPEG/RTSP camera, choose the network URL option and enter its full URL.

Daily operation:

1. Power on the physical robot.
2. Start the Ubuntu VM; Docker services start automatically.
3. Open Robot Control v2 on Windows/macOS.
4. Connect to the Ubuntu VM.
5. Confirm LiDAR telemetry and test emergency stop with the wheels lifted.
6. Test manual control at low speed, then start Follow.

The bridge blocks forward movement if LiDAR data is stale. The command watchdog stops
the robot if GUI heartbeat is absent for 0.7 seconds.

## Tests

Tests that do not require ROS or a camera:

```bash
python3 -m unittest discover -s ubuntu_v2/tests -v
```
